package net.mcreator.test.block;

import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.component.TooltipDisplay;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;
import net.minecraft.network.chat.Component;

import net.mcreator.test.init.ScarymodorsmthngidkModBlocks;

import java.util.function.Consumer;

public class WelcometohellBlock extends Block {
	public WelcometohellBlock(BlockBehaviour.Properties properties) {
		super(properties.sound(SoundType.NETHERITE_BLOCK).strength(1000f, 10f));
	}

	public static class Item extends BlockItem {
		public Item(Item.Properties properties) {
			super(ScarymodorsmthngidkModBlocks.WELCOMETOHELL.get(), properties);
		}

		@Override
		public void appendHoverText(ItemStack itemstack, Item.TooltipContext context, TooltipDisplay tooltipDisplay, Consumer<Component> componentConsumer, TooltipFlag flag) {
			super.appendHoverText(itemstack, context, tooltipDisplay, componentConsumer, flag);
			componentConsumer.accept(Component.translatable("block.scarymodorsmthngidk.welcometohell.description_0"));
		}
	}
}