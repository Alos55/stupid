package net.mcreator.test.block;

import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.FallingBlock;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.core.BlockPos;

import com.mojang.serialization.MapCodec;

public class Test22222222Block extends FallingBlock {
	public static final MapCodec<Test22222222Block> CODEC = simpleCodec(Test22222222Block::new);

	@Override
	public MapCodec<Test22222222Block> codec() {
		return CODEC;
	}

	@Override
	public int getDustColor(BlockState blockstate, BlockGetter world, BlockPos pos) {
		return blockstate.getMapColor(world, pos).col;
	}

	public Test22222222Block(BlockBehaviour.Properties properties) {
		super(properties.sound(SoundType.NETHER_ORE).strength(-1, 3600000));
	}
}