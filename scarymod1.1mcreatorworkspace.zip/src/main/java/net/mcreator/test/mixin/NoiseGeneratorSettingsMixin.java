package net.mcreator.test.mixin;

import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.Mixin;

import net.minecraft.world.level.levelgen.SurfaceRules;
import net.minecraft.world.level.levelgen.NoiseGeneratorSettings;
import net.minecraft.world.level.dimension.DimensionType;
import net.minecraft.core.Holder;

import net.mcreator.test.init.ScarymodorsmthngidkModBiomes;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapmethod.WrapMethod;

@Mixin(NoiseGeneratorSettings.class)
public class NoiseGeneratorSettingsMixin implements ScarymodorsmthngidkModBiomes.ScarymodorsmthngidkModNoiseGeneratorSettings {
	@Unique
	private Holder<DimensionType> scarymodorsmthngidk_dimensionTypeReference;

	@WrapMethod(method = "surfaceRule")
	public SurfaceRules.RuleSource surfaceRule(Operation<SurfaceRules.RuleSource> original) {
		SurfaceRules.RuleSource retval = original.call();
		if (this.scarymodorsmthngidk_dimensionTypeReference != null) {
			retval = ScarymodorsmthngidkModBiomes.adaptSurfaceRule(retval, this.scarymodorsmthngidk_dimensionTypeReference);
		}
		return retval;
	}

	@Override
	public void setscarymodorsmthngidkDimensionTypeReference(Holder<DimensionType> dimensionType) {
		this.scarymodorsmthngidk_dimensionTypeReference = dimensionType;
	}
}