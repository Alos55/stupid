package net.mcreator.test.procedures;

import net.neoforged.neoforge.event.tick.LevelTickEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.bus.api.Event;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.util.RandomSource;
import net.minecraft.util.Mth;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.network.chat.Component;
import net.minecraft.ChatFormatting;

import javax.annotation.Nullable;

@EventBusSubscriber
public class MeowProcedure {
	@SubscribeEvent
	public static void onWorldTick(LevelTickEvent.Post event) {
		execute(event, event.getLevel());
	}

	public static void execute(LevelAccessor world) {
		execute(null, world);
	}

	private static void execute(@Nullable Event event, LevelAccessor world) {
		if (3 == Mth.nextInt(RandomSource.create(), 1, 400)) {
			if (3 == Mth.nextInt(RandomSource.create(), 1, 100)) {
				if (world instanceof ServerLevel _level) {
					_level.getServer().getPlayerList().broadcastSystemMessage(Component.literal("Meow, mrrppp").withColor(0x00ffcc), false);
				}
			} else if (7 == Mth.nextInt(RandomSource.create(), 1, 100)) {
				if (world instanceof ServerLevel _level) {
					_level.getServer().getPlayerList().broadcastSystemMessage(Component.literal("Mrowww :3"), false);
				}
			} else if (20 == Mth.nextInt(RandomSource.create(), 1, 100)) {
				if (world instanceof ServerLevel _level) {
					_level.getServer().getPlayerList().broadcastSystemMessage(Component.literal("mraow :3").withColor(0x990099), false);
				}
			} else if (10 == Mth.nextInt(RandomSource.create(), 1, 100)) {
				if (world instanceof ServerLevel _level) {
					_level.getServer().getPlayerList().broadcastSystemMessage(Component.literal("being evil is so tiring. can you get me mcdonalds pwease").withColor(0x666666), false);
				}
			} else if (12 == Mth.nextInt(RandomSource.create(), 1, 100)) {
				if (world instanceof ServerLevel _level) {
					_level.getServer().getPlayerList().broadcastSystemMessage(Component.literal("im gona eat you muhahhahahah").withColor(0xff0000).withStyle(ChatFormatting.BOLD), false);
				}
			} else if (50 == Mth.nextInt(RandomSource.create(), 1, 100)) {
				if (world instanceof ServerLevel _level) {
					_level.getServer().getPlayerList().broadcastSystemMessage(Component.literal("do you have games on yo phone"), false);
				}
			} else if (18 == Mth.nextInt(RandomSource.create(), 1, 100)) {
				if (world instanceof ServerLevel _level) {
					_level.getServer().getPlayerList().broadcastSystemMessage(Component.literal("MRBEASTGAMING joined").withColor(0xcccc00).withStyle(ChatFormatting.BOLD), false);
				}
			} else if (14 == Mth.nextInt(RandomSource.create(), 1, 100)) {
				if (world instanceof ServerLevel _level) {
					_level.getServer().getPlayerList().broadcastSystemMessage(Component.literal("im gay").withStyle(ChatFormatting.BOLD).withStyle(ChatFormatting.ITALIC).withStyle(ChatFormatting.UNDERLINE), false);
				}
			} else if (42 == Mth.nextInt(RandomSource.create(), 1, 100)) {
				if (world instanceof ServerLevel _level) {
					_level.getServer().getPlayerList().broadcastSystemMessage(Component.literal("why did you kill him bruv"), false);
				}
			} else if (15 == Mth.nextInt(RandomSource.create(), 1, 100)) {
				if (world instanceof ServerLevel _level) {
					_level.getServer().getPlayerList().broadcastSystemMessage(Component.literal("you are so boring. go play fortnite or smthng "), false);
				}
			} else if (100 == Mth.nextInt(RandomSource.create(), 1, 100)) {
				if (world instanceof ServerLevel _level) {
					_level.getServer().getPlayerList().broadcastSystemMessage(Component.literal("im gona touch youuuuu").withColor(0x006666), false);
				}
			} else if (100 == Mth.nextInt(RandomSource.create(), 1, 100)) {
				if (world instanceof ServerLevel _level) {
					_level.getServer().getPlayerList().broadcastSystemMessage(Component.literal("MRBEASTGAMING left").withColor(0xffff00).withStyle(ChatFormatting.BOLD), false);
				}
			}
		}
	}
}