/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.test.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.test.block.WelcometohellBlock;
import net.mcreator.test.ScarymodorsmthngidkMod;

import java.util.function.Function;

public class ScarymodorsmthngidkModItems {
	public static final DeferredRegister.Items REGISTRY = DeferredRegister.createItems(ScarymodorsmthngidkMod.MODID);
	public static final DeferredItem<Item> TESTBLOCK;
	public static final DeferredItem<Item> TEST_22222222;
	public static final DeferredItem<Item> WELCOMETOHELL;
	static {
		TESTBLOCK = block(ScarymodorsmthngidkModBlocks.TESTBLOCK, new Item.Properties().rarity(Rarity.EPIC));
		TEST_22222222 = block(ScarymodorsmthngidkModBlocks.TEST_22222222, new Item.Properties().rarity(Rarity.RARE));
		WELCOMETOHELL = register("welcometohell", properties -> new WelcometohellBlock.Item(properties.rarity(Rarity.EPIC)));
	}

	// Start of user code block custom items
	// End of user code block custom items
	private static <I extends Item> DeferredItem<I> register(String name, Function<Item.Properties, ? extends I> supplier) {
		return REGISTRY.registerItem(name, supplier, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block) {
		return block(block, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block, Item.Properties properties) {
		return REGISTRY.registerItem(block.getId().getPath(), prop -> new BlockItem(block.get(), prop), properties);
	}
}