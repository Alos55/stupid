/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.test.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.sounds.SoundEvent;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.registries.Registries;

import net.mcreator.test.ScarymodorsmthngidkMod;

public class ScarymodorsmthngidkModSounds {
	public static final DeferredRegister<SoundEvent> REGISTRY = DeferredRegister.create(Registries.SOUND_EVENT, ScarymodorsmthngidkMod.MODID);
	public static final DeferredHolder<SoundEvent, SoundEvent> BOO = REGISTRY.register("boo", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("scarymodorsmthngidk", "boo")));
}