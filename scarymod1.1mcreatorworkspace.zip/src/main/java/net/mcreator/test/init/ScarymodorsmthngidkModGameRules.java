/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.test.init;

import net.neoforged.fml.event.lifecycle.FMLCommonSetupEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.level.GameRules;

@EventBusSubscriber
public class ScarymodorsmthngidkModGameRules {
	public static GameRules.Key<GameRules.BooleanValue> DIDGETFORCEFEMD;

	@SubscribeEvent
	public static void registerGameRules(FMLCommonSetupEvent event) {
		DIDGETFORCEFEMD = GameRules.register("didgetforcefemd", GameRules.Category.PLAYER, GameRules.BooleanValue.create(true));
	}
}