/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.test.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredBlock;

import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.Block;

import net.mcreator.test.block.WelcometohellBlock;
import net.mcreator.test.block.TestblockBlock;
import net.mcreator.test.block.Test22222222Block;
import net.mcreator.test.ScarymodorsmthngidkMod;

import java.util.function.Function;

public class ScarymodorsmthngidkModBlocks {
	public static final DeferredRegister.Blocks REGISTRY = DeferredRegister.createBlocks(ScarymodorsmthngidkMod.MODID);
	public static final DeferredBlock<Block> TESTBLOCK;
	public static final DeferredBlock<Block> TEST_22222222;
	public static final DeferredBlock<Block> WELCOMETOHELL;
	static {
		TESTBLOCK = register("testblock", TestblockBlock::new);
		TEST_22222222 = register("test_22222222", Test22222222Block::new);
		WELCOMETOHELL = register("welcometohell", WelcometohellBlock::new);
	}

	// Start of user code block custom blocks
	// End of user code block custom blocks
	private static <B extends Block> DeferredBlock<B> register(String name, Function<BlockBehaviour.Properties, ? extends B> supplier) {
		return REGISTRY.registerBlock(name, supplier);
	}
}